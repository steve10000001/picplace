import 'package:flutter/material.dart';

void main() {
  runApp(PicPlaceApp());
}

class PicPlaceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PicPlace',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Image> images = [];

  void _addPicture() {
    setState(() {
      images.add(Image.asset('assets/sample_picture.png'));
    });
  }

  void _clearPictures() {
    setState(() {
      images.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PicPlace'),
        actions: [
          IconButton(icon: Icon(Icons.info_outline), onPressed: () {
            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: Text('Placement Tips'),
                content: Text('Use guidelines and symmetry for best picture placement.'),
              ),
            );
          }),
          IconButton(icon: Icon(Icons.delete), onPressed: _clearPictures),
        ],
      ),
      body: Stack(
        children: images,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addPicture,
        child: Icon(Icons.add),
        tooltip: 'Add Picture',
      ),
    );
  }
}
